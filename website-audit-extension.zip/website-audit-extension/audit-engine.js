/**
 * Website Audit Extension - Audit Engine
 * Processes raw DOM data into structured findings and scores
 * TalhaImtiazWorks
 */

const AuditEngine = {
  CATEGORIES: {
    SEO: { weight: 20, name: 'SEO' },
    Accessibility: { weight: 20, name: 'Accessibility' },
    Performance: { weight: 20, name: 'Performance' },
    Mobile: { weight: 15, name: 'Mobile' },
    Content: { weight: 10, name: 'Content' },
    UX: { weight: 10, name: 'UX / Conversion' },
    Technical: { weight: 5, name: 'Technical' }
  },

  run(rawData) {
    if (!rawData) {
      return this.createErrorResult('No data received from page');
    }

    try {
      const findings = [];
      const categoryScores = {};

      const modules = [
        { key: 'SEO', fn: this.auditSEO },
        { key: 'Accessibility', fn: this.auditAccessibility },
        { key: 'Performance', fn: this.auditPerformance },
        { key: 'Mobile', fn: this.auditMobile },
        { key: 'Content', fn: this.auditContent },
        { key: 'UX', fn: this.auditUX },
        { key: 'Technical', fn: this.auditTechnical }
      ];

      for (const mod of modules) {
        try {
          const result = mod.fn.call(this, rawData);
          findings.push(...result.findings);
          categoryScores[mod.key] = Math.max(0, Math.min(100, result.score));
        } catch (modError) {
          console.error('Audit module ' + mod.key + ' failed:', modError);
          findings.push({
            id: mod.key.toLowerCase() + '-module-error',
            category: mod.key,
            severity: 'info',
            title: mod.key + ' check could not complete',
            description: 'An error occurred during this audit module.',
            recommendation: null,
            impact: 0,
            passed: false
          });
          categoryScores[mod.key] = 0;
        }
      }

      const overall = Math.round(
        (categoryScores.SEO * 0.20) +
        (categoryScores.Accessibility * 0.20) +
        (categoryScores.Performance * 0.20) +
        (categoryScores.Mobile * 0.15) +
        (categoryScores.Content * 0.10) +
        (categoryScores.UX * 0.10) +
        (categoryScores.Technical * 0.05)
      );

      const recs = this.generateRecommendations(findings);

      return {
        website: {
          url: rawData.url || '',
          title: rawData.title || '',
          domain: rawData.domain || '',
          protocol: rawData.protocol || '',
          language: rawData.language || null,
          auditedAt: new Date().toISOString()
        },
        overallScore: Math.max(0, Math.min(100, overall)),
        categories: categoryScores,
        findings: findings,
        recommendations: recs,
        passedChecks: findings.filter(f => f.severity === 'passed'),
        warnings: findings.filter(f => f.severity === 'warning'),
        criticalIssues: findings.filter(f => f.severity === 'critical'),
        infoItems: findings.filter(f => f.severity === 'info'),
        rawData: rawData
      };
    } catch (error) {
      console.error('Audit engine failed:', error);
      return this.createErrorResult(error.message);
    }
  },

  createErrorResult(message) {
    return {
      website: { url: '', title: '', domain: '', auditedAt: new Date().toISOString() },
      overallScore: 0,
      categories: { SEO: 0, Accessibility: 0, Performance: 0, Mobile: 0, Content: 0, UX: 0, Technical: 0 },
      findings: [{
        id: 'audit-error',
        category: 'Technical',
        severity: 'critical',
        title: 'Audit could not complete',
        description: message,
        recommendation: 'Try refreshing the page and running the audit again.',
        impact: 100,
        passed: false
      }],
      recommendations: [],
      passedChecks: [],
      warnings: [],
      criticalIssues: [],
      infoItems: [],
      rawData: null
    };
  },

  auditSEO(data) {
    let score = 100;
    const findings = [];
    const d = data || {};
    const meta = d.meta || {};
    const headings = d.headings || {};
    const links = d.links || [];
    const og = d.og || {};
    const technical = d.technical || {};

    const title = (d.title || '').trim();
    if (!title) {
      score -= 25;
      findings.push({
        id: 'seo-title-missing', category: 'SEO', severity: 'critical',
        title: 'Page title is missing',
        description: 'No <title> tag was detected on this page.',
        recommendation: 'Add a descriptive, unique title tag (50-60 characters) that accurately describes the page content.',
        impact: 25, passed: false
      });
    } else {
      const titleLen = title.length;
      let titleStatus = 'reasonable';
      let titleSeverity = 'passed';
      let titleRec = null;
      let titleImpact = 0;

      if (titleLen < 10) {
        titleStatus = 'too short'; titleSeverity = 'warning';
        titleRec = 'Your title is very short. Expand it to 50-60 characters for better search visibility.';
        titleImpact = 10; score -= 10;
      } else if (titleLen > 70) {
        titleStatus = 'excessively long'; titleSeverity = 'warning';
        titleRec = 'Your title exceeds 70 characters and may be truncated in search results. Keep it under 60 characters.';
        titleImpact = 10; score -= 10;
      }

      findings.push({
        id: 'seo-title-present', category: 'SEO', severity: titleSeverity,
        title: 'Title tag detected (' + titleLen + ' characters)',
        description: 'Title: "' + title + '" - ' + titleStatus,
        recommendation: titleRec,
        impact: titleImpact, passed: titleSeverity === 'passed'
      });
    }

    const desc = (meta.description || '').trim();
    if (!desc) {
      score -= 15;
      findings.push({
        id: 'seo-meta-description-missing', category: 'SEO', severity: 'warning',
        title: 'Meta description is missing',
        description: 'No meta description was detected on this page.',
        recommendation: 'Add a unique meta description (150-160 characters) that summarizes the page and encourages clicks.',
        impact: 15, passed: false
      });
    } else {
      const descLen = desc.length;
      let descStatus = 'reasonable length';
      let descSeverity = 'passed';
      let descRec = null;
      let descImpact = 0;

      if (descLen < 50) {
        descStatus = 'too short'; descSeverity = 'warning';
        descRec = 'Your meta description is quite short. Aim for 150-160 characters.';
        descImpact = 5; score -= 5;
      } else if (descLen > 170) {
        descStatus = 'excessively long'; descSeverity = 'warning';
        descRec = 'Your meta description may be truncated in search results. Keep it under 160 characters.';
        descImpact = 5; score -= 5;
      }

      findings.push({
        id: 'seo-meta-description-present', category: 'SEO', severity: descSeverity,
        title: 'Meta description detected (' + descLen + ' characters)',
        description: 'Meta description is ' + descStatus + '.',
        recommendation: descRec,
        impact: descImpact, passed: descSeverity === 'passed'
      });
    }

    const h1 = headings.h1 || { count: 0, texts: [] };
    if (h1.count === 0) {
      score -= 20;
      findings.push({
        id: 'seo-h1-missing', category: 'SEO', severity: 'critical',
        title: 'H1 heading is missing',
        description: 'No H1 heading was found on this page.',
        recommendation: 'Add a single H1 heading that describes the main topic of the page.',
        impact: 20, passed: false
      });
    } else if (h1.count > 1) {
      score -= 10;
      findings.push({
        id: 'seo-multiple-h1', category: 'SEO', severity: 'warning',
        title: 'Multiple H1 headings detected',
        description: h1.count + ' H1 elements were found. Best practice is to use exactly one H1 per page.',
        recommendation: 'Consolidate to a single H1 heading. Use H2-H6 for subsections.',
        impact: 10, passed: false
      });
    } else {
      findings.push({
        id: 'seo-h1-present', category: 'SEO', severity: 'passed',
        title: 'H1 heading detected',
        description: 'H1: "' + (h1.texts[0] || '') + '"',
        recommendation: null,
        impact: 0, passed: true
      });
    }

    if (meta.canonical) {
      findings.push({
        id: 'seo-canonical-present', category: 'SEO', severity: 'passed',
        title: 'Canonical URL detected',
        description: 'Canonical: ' + meta.canonical,
        recommendation: null,
        impact: 0, passed: true
      });
    } else {
      findings.push({
        id: 'seo-canonical-missing', category: 'SEO', severity: 'info',
        title: 'Canonical URL not detected',
        description: 'No canonical link tag was found.',
        recommendation: 'Consider adding a canonical URL to prevent duplicate content issues.',
        impact: 0, passed: false
      });
    }

    const robots = (meta.robots || '').toLowerCase();
    if (robots.includes('noindex')) {
      score -= 15;
      findings.push({
        id: 'seo-robots-blocking', category: 'SEO', severity: 'warning',
        title: 'Robots meta blocks indexing',
        description: 'Robots meta: "' + meta.robots + '"',
        recommendation: 'Remove "noindex" if this page should appear in search results.',
        impact: 15, passed: false
      });
    } else if (robots) {
      findings.push({
        id: 'seo-robots-present', category: 'SEO', severity: 'passed',
        title: 'Robots meta tag detected',
        description: 'Robots: "' + meta.robots + '"',
        recommendation: null,
        impact: 0, passed: true
      });
    } else {
      findings.push({
        id: 'seo-robots-missing', category: 'SEO', severity: 'info',
        title: 'No robots meta tag detected',
        description: 'Default crawling behavior will apply.',
        recommendation: null,
        impact: 0, passed: true
      });
    }

    if (d.language) {
      findings.push({
        id: 'seo-lang-present', category: 'SEO', severity: 'passed',
        title: 'HTML language declared',
        description: 'Language: ' + d.language,
        recommendation: null,
        impact: 0, passed: true
      });
    } else {
      score -= 10;
      findings.push({
        id: 'seo-lang-missing', category: 'SEO', severity: 'warning',
        title: 'HTML language not declared',
        description: 'No lang attribute was found on the <html> element.',
        recommendation: 'Add a lang attribute (e.g., lang="en") to help search engines and screen readers.',
        impact: 10, passed: false
      });
    }

    const ogPresent = og.title || og.description || og.image;
    if (ogPresent) {
      findings.push({
        id: 'seo-og-present', category: 'SEO', severity: 'passed',
        title: 'Open Graph tags detected',
        description: 'Found: ' + [og.title && 'title', og.description && 'description', og.image && 'image'].filter(Boolean).join(', '),
        recommendation: null,
        impact: 0, passed: true
      });
    } else {
      findings.push({
        id: 'seo-og-missing', category: 'SEO', severity: 'info',
        title: 'Open Graph tags not detected',
        description: 'No Open Graph meta tags were found.',
        recommendation: 'Add Open Graph tags for better social media sharing previews.',
        impact: 0, passed: false
      });
    }

    if (technical.structuredDataCount > 0) {
      findings.push({
        id: 'seo-structured-data-present', category: 'SEO', severity: 'passed',
        title: 'Structured data detected',
        description: technical.structuredDataCount + ' JSON-LD script(s) found.',
        recommendation: null,
        impact: 0, passed: true
      });
    } else {
      findings.push({
        id: 'seo-structured-data-missing', category: 'SEO', severity: 'info',
        title: 'No structured data detected',
        description: 'No JSON-LD or Schema.org markup was found.',
        recommendation: 'Consider adding structured data to enhance search result appearance.',
        impact: 0, passed: false
      });
    }

    const internalLinks = links.filter(l => !l.isExternal && l.hasHref).length;
    const externalLinks = links.filter(l => l.isExternal).length;
    const emptyLinks = links.filter(l => l.isEmpty).length;

    findings.push({
      id: 'seo-links-summary', category: 'SEO', severity: 'info',
      title: 'Link structure summary',
      description: internalLinks + ' internal, ' + externalLinks + ' external, ' + links.length + ' total links.',
      recommendation: null,
      impact: 0, passed: true
    });

    if (emptyLinks > 0) {
      score -= 10;
      findings.push({
        id: 'seo-empty-links', category: 'SEO', severity: 'warning',
        title: 'Empty or broken links detected',
        description: emptyLinks + ' link(s) with empty or fragment-only hrefs found.',
        recommendation: 'Fix or remove links with empty hrefs, "#", or JavaScript hrefs.',
        impact: 10, passed: false
      });
    }

    return { score: Math.max(0, score), findings };
  },

  auditAccessibility(data) {
    let score = 100;
    const findings = [];
    const d = data || {};
    const acc = d.accessibility || {};

    if (acc.htmlLang) {
      findings.push({
        id: 'acc-lang-present', category: 'Accessibility', severity: 'passed',
        title: 'HTML language declared',
        description: 'Language: ' + acc.htmlLang,
        recommendation: null,
        impact: 0, passed: true
      });
    } else {
      score -= 15;
      findings.push({
        id: 'acc-lang-missing', category: 'Accessibility', severity: 'warning',
        title: 'HTML language not declared',
        description: 'The <html> element is missing a lang attribute.',
        recommendation: 'Add lang="en" (or appropriate language code) to the <html> tag.',
        impact: 15, passed: false
      });
    }

    const withoutAlt = acc.imagesWithoutAlt || 0;
    const withEmptyAlt = acc.imagesWithEmptyAlt || 0;
    const withAlt = acc.imagesWithAlt || 0;
    const totalImages = acc.totalImages || 0;

    if (withoutAlt > 0) {
      score -= 15;
      findings.push({
        id: 'acc-images-no-alt', category: 'Accessibility', severity: 'warning',
        title: 'Images missing alt text',
        description: withoutAlt + ' of ' + totalImages + ' images lack alt attributes.',
        recommendation: 'Add descriptive alt text to informative images. Decorative images may use empty alt="".',
        impact: 15, passed: false
      });
    }

    if (withEmptyAlt > 0) {
      findings.push({
        id: 'acc-images-empty-alt', category: 'Accessibility', severity: 'info',
        title: 'Images with empty alt text',
        description: withEmptyAlt + ' image(s) use empty alt attributes. These may be decorative.',
        recommendation: 'Ensure empty alt is intentional for decorative images only.',
        impact: 0, passed: true
      });
    }

    if (withAlt > 0) {
      findings.push({
        id: 'acc-images-alt-present', category: 'Accessibility', severity: 'passed',
        title: 'Images with alt text detected',
        description: withAlt + ' image(s) have alt attributes.',
        recommendation: null,
        impact: 0, passed: true
      });
    }

    const inputsWithoutLabels = acc.formInputsWithoutLabels || 0;
    if (inputsWithoutLabels > 0) {
      score -= 15;
      findings.push({
        id: 'acc-form-inputs-no-label', category: 'Accessibility', severity: 'warning',
        title: 'Form inputs without labels',
        description: inputsWithoutLabels + ' form input(s) lack associated labels.',
        recommendation: 'Add <label> elements with for attributes, or use aria-label/aria-labelledby.',
        impact: 15, passed: false
      });
    } else if ((d.forms || []).length > 0) {
      findings.push({
        id: 'acc-form-inputs-labeled', category: 'Accessibility', severity: 'passed',
        title: 'Form inputs have labels',
        description: 'All detected form inputs appear to have labels or accessible names.',
        recommendation: null,
        impact: 0, passed: true
      });
    }

    const emptyLinks = acc.emptyLinks || 0;
    if (emptyLinks > 0) {
      score -= 20;
      findings.push({
        id: 'acc-empty-links', category: 'Accessibility', severity: 'critical',
        title: 'Empty or broken links detected',
        description: emptyLinks + ' link(s) have empty or invalid hrefs.',
        recommendation: 'Remove or fix links with empty hrefs, "#", or JavaScript URLs.',
        impact: 20, passed: false
      });
    }

    const iconOnlyLinks = acc.linksWithOnlyIcons || 0;
    if (iconOnlyLinks > 0) {
      score -= 10;
      findings.push({
        id: 'acc-icon-only-links', category: 'Accessibility', severity: 'warning',
        title: 'Icon-only links without accessible names',
        description: iconOnlyLinks + ' link(s) contain only icons without accessible labels.',
        recommendation: 'Add aria-label or visually hidden text to icon-only links.',
        impact: 10, passed: false
      });
    }

    const buttonsNoText = acc.buttonsWithoutText || 0;
    if (buttonsNoText > 0) {
      score -= 10;
      findings.push({
        id: 'acc-buttons-no-text', category: 'Accessibility', severity: 'warning',
        title: 'Buttons without accessible text',
        description: buttonsNoText + ' button(s) lack visible text or aria-label.',
        recommendation: 'Add text content or aria-label to all buttons.',
        impact: 10, passed: false
      });
    }

    const headings = d.headings || {};
    let hierarchyBroken = false;
    let prevLevel = 0;
    for (let i = 1; i <= 6; i++) {
      const h = headings['h' + i];
      if (h && h.count > 0) {
        if (prevLevel > 0 && i > prevLevel + 1) {
          hierarchyBroken = true;
        }
        prevLevel = i;
      }
    }
    if (hierarchyBroken) {
      score -= 10;
      findings.push({
        id: 'acc-heading-hierarchy', category: 'Accessibility', severity: 'warning',
        title: 'Heading hierarchy issue detected',
        description: 'Heading levels appear to skip (e.g., H1 to H3 without H2).',
        recommendation: 'Use heading levels sequentially without skipping.',
        impact: 10, passed: false
      });
    } else if (prevLevel > 0) {
      findings.push({
        id: 'acc-heading-hierarchy-ok', category: 'Accessibility', severity: 'passed',
        title: 'Heading hierarchy looks reasonable',
        description: 'No major heading level skips detected.',
        recommendation: null,
        impact: 0, passed: true
      });
    }

    const landmarks = acc.ariaLandmarks || [];
    if (landmarks.length > 0) {
      findings.push({
        id: 'acc-landmarks-present', category: 'Accessibility', severity: 'passed',
        title: 'ARIA landmarks detected',
        description: 'Found: ' + landmarks.slice(0, 8).join(', ') + (landmarks.length > 8 ? '...' : ''),
        recommendation: null,
        impact: 0, passed: true
      });
    } else {
      findings.push({
        id: 'acc-landmarks-missing', category: 'Accessibility', severity: 'info',
        title: 'No ARIA landmarks detected',
        description: 'Consider using semantic HTML5 elements or ARIA roles for page regions.',
        recommendation: 'Use <nav>, <main>, <aside>, <footer>, or role attributes for better navigation.',
        impact: 0, passed: false
      });
    }

    if (acc.skipLinkExists) {
      findings.push({
        id: 'acc-skip-link', category: 'Accessibility', severity: 'passed',
        title: 'Skip navigation link detected',
        description: 'A skip-to-content link was found.',
        recommendation: null,
        impact: 0, passed: true
      });
    } else {
      findings.push({
        id: 'acc-skip-link-missing', category: 'Accessibility', severity: 'info',
        title: 'No skip navigation link detected',
        description: 'A skip link helps keyboard users bypass repetitive navigation.',
        recommendation: 'Add a "Skip to main content" link as the first focusable element.',
        impact: 0, passed: false
      });
    }

    return { score: Math.max(0, score), findings };
  },

  auditPerformance(data) {
    let score = 100;
    const findings = [];
    const d = data || {};
    const perf = d.performance || {};
    const images = d.images || [];

    const domCount = perf.domElementCount || 0;
    if (domCount > 1500) {
      score -= 15;
      findings.push({
        id: 'perf-dom-large', category: 'Performance', severity: 'warning',
        title: 'Large DOM size detected',
        description: domCount.toLocaleString() + ' DOM elements found. Large DOMs can slow rendering.',
        recommendation: 'Reduce DOM depth and element count. Consider pagination or virtual scrolling.',
        impact: 15, passed: false
      });
    } else {
      findings.push({
        id: 'perf-dom-ok', category: 'Performance', severity: 'passed',
        title: 'DOM size is reasonable',
        description: domCount.toLocaleString() + ' DOM elements.',
        recommendation: null,
        impact: 0, passed: true
      });
    }

    const imgNoDims = perf.imagesWithoutDimensions || 0;
    if (imgNoDims > 0) {
      score -= 15;
      findings.push({
        id: 'perf-img-no-dims', category: 'Performance', severity: 'warning',
        title: 'Images missing width/height attributes',
        description: imgNoDims + ' image(s) lack explicit width and height attributes.',
        recommendation: 'Add width and height attributes to images to prevent layout shifts.',
        impact: 15, passed: false
      });
    } else if (images.length > 0) {
      findings.push({
        id: 'perf-img-dims-ok', category: 'Performance', severity: 'passed',
        title: 'Images have dimensions',
        description: 'All detected images have width and height attributes.',
        recommendation: null,
        impact: 0, passed: true
      });
    }

    const largeImgs = perf.largeImages || 0;
    if (largeImgs > 0) {
      score -= 10;
      findings.push({
        id: 'perf-img-large', category: 'Performance', severity: 'warning',
        title: 'Oversized images detected',
        description: largeImgs + ' image(s) exceed 2000px in width or height.',
        recommendation: 'Resize and compress images. Serve appropriately sized images for the viewport.',
        impact: 10, passed: false
      });
    }

    const scriptCount = perf.scriptCount || 0;
    if (scriptCount > 20) {
      score -= 10;
      findings.push({
        id: 'perf-many-scripts', category: 'Performance', severity: 'warning',
        title: 'High number of scripts',
        description: scriptCount + ' script(s) detected on the page.',
        recommendation: 'Consolidate scripts, remove unused ones, and use async/defer where possible.',
        impact: 10, passed: false
      });
    } else {
      findings.push({
        id: 'perf-scripts-ok', category: 'Performance', severity: 'passed',
        title: 'Script count is reasonable',
        description: scriptCount + ' script(s).',
        recommendation: null,
        impact: 0, passed: true
      });
    }

    const styleCount = perf.stylesheetCount || 0;
    if (styleCount > 10) {
      score -= 10;
      findings.push({
        id: 'perf-many-styles', category: 'Performance', severity: 'warning',
        title: 'High number of stylesheets',
        description: styleCount + ' stylesheet(s) detected.',
        recommendation: 'Consolidate CSS files to reduce HTTP requests.',
        impact: 10, passed: false
      });
    }

    const docSize = perf.documentSize || 0;
    const docSizeKB = Math.round(docSize / 1024);
    if (docSizeKB > 500) {
      score -= 10;
      findings.push({
        id: 'perf-doc-large', category: 'Performance', severity: 'warning',
        title: 'Large HTML document size',
        description: 'Document size: ' + docSizeKB + ' KB.',
        recommendation: 'Reduce HTML size by removing unused markup, comments, and inline styles.',
        impact: 10, passed: false
      });
    }

    const rbScripts = perf.renderBlockingScripts || 0;
    const rbStyles = perf.renderBlockingStyles || 0;
    if (rbScripts > 0) {
      score -= 10;
      findings.push({
        id: 'perf-render-blocking-scripts', category: 'Performance', severity: 'warning',
        title: 'Render-blocking scripts in <head>',
        description: rbScripts + ' script(s) in <head> without async or defer.',
        recommendation: 'Move non-critical scripts to the bottom of <body> or add async/defer.',
        impact: 10, passed: false
      });
    }
    if (rbStyles > 0) {
      score -= 10;
      findings.push({
        id: 'perf-render-blocking-styles', category: 'Performance', severity: 'warning',
        title: 'Render-blocking stylesheets in <head>',
        description: rbStyles + ' stylesheet(s) in <head> may block rendering.',
        recommendation: 'Consider inlining critical CSS and loading non-critical CSS asynchronously.',
        impact: 10, passed: false
      });
    }

    const resCount = perf.resourceCount || 0;
    findings.push({
      id: 'perf-resources', category: 'Performance', severity: 'info',
      title: 'Resource count',
      description: (resCount !== null ? resCount : 'Not available') + ' resources loaded.',
      recommendation: resCount > 100 ? 'Consider reducing total resource count.' : null,
      impact: 0, passed: true
    });

    const lazyImages = images.filter(img => img.isLazy).length;
    if (lazyImages > 0) {
      findings.push({
        id: 'perf-lazy-loading', category: 'Performance', severity: 'passed',
        title: 'Lazy loading used',
        description: lazyImages + ' image(s) use loading="lazy".',
        recommendation: null,
        impact: 0, passed: true
      });
    }

    if (perf.timing) {
      const t = perf.timing;
      findings.push({
        id: 'perf-timing', category: 'Performance', severity: 'info',
        title: 'Page load timing available',
        description: 'DOM ready: ' + t.domContentLoaded + 'ms | Load: ' + t.loadComplete + 'ms',
        recommendation: null,
        impact: 0, passed: true
      });
    } else {
      findings.push({
        id: 'perf-timing-unavailable', category: 'Performance', severity: 'info',
        title: 'Detailed timing not available',
        description: 'Navigation timing API data could not be retrieved.',
        recommendation: null,
        impact: 0, passed: false
      });
    }

    return { score: Math.max(0, score), findings };
  },

  auditMobile(data) {
    let score = 100;
    const findings = [];
    const d = data || {};
    const mobile = d.mobile || {};

    if (mobile.viewportMetaExists) {
      findings.push({
        id: 'mobile-viewport-present', category: 'Mobile', severity: 'passed',
        title: 'Viewport meta tag detected',
        description: 'Viewport: ' + (mobile.viewportContent || 'present'),
        recommendation: null,
        impact: 0, passed: true
      });

      if (mobile.hasWidthDeviceWidth) {
        findings.push({
          id: 'mobile-viewport-width', category: 'Mobile', severity: 'passed',
          title: 'Viewport width set to device-width',
          description: 'The viewport is configured to match device width.',
          recommendation: null,
          impact: 0, passed: true
        });
      } else {
        score -= 15;
        findings.push({
          id: 'mobile-viewport-width-missing', category: 'Mobile', severity: 'critical',
          title: 'Viewport missing width=device-width',
          description: 'The viewport meta tag does not include width=device-width.',
          recommendation: 'Add width=device-width to your viewport meta tag for proper mobile scaling.',
          impact: 15, passed: false
        });
      }

      if (mobile.hasInitialScale) {
        findings.push({
          id: 'mobile-initial-scale', category: 'Mobile', severity: 'passed',
          title: 'Initial scale configured',
          description: 'Viewport includes an initial-scale setting.',
          recommendation: null,
          impact: 0, passed: true
        });
      }
    } else {
      score -= 30;
      findings.push({
        id: 'mobile-viewport-missing', category: 'Mobile', severity: 'critical',
        title: 'Viewport meta tag missing',
        description: 'No viewport meta tag was found. The page may not render correctly on mobile devices.',
        recommendation: 'Add <meta name="viewport" content="width=device-width, initial-scale=1"> to <head>.',
        impact: 30, passed: false
      });
    }

    if (mobile.horizontalOverflow) {
      score -= 25;
      findings.push({
        id: 'mobile-horizontal-overflow', category: 'Mobile', severity: 'critical',
        title: 'Potential horizontal overflow detected',
        description: 'Document width (' + mobile.scrollWidth + 'px) exceeds viewport width (' + mobile.windowWidth + 'px).',
        recommendation: 'Check for elements with fixed widths, large images, or tables that exceed the viewport.',
        impact: 25, passed: false
      });
    } else {
      findings.push({
        id: 'mobile-no-overflow', category: 'Mobile', severity: 'passed',
        title: 'No horizontal overflow detected',
        description: 'Document fits within the current viewport width.',
        recommendation: null,
        impact: 0, passed: true
      });
    }

    if (mobile.fixedWidthElements > 0) {
      score -= 15;
      findings.push({
        id: 'mobile-fixed-width', category: 'Mobile', severity: 'warning',
        title: 'Fixed-width elements detected',
        description: mobile.fixedWidthElements + ' element(s) have fixed widths exceeding the viewport.',
        recommendation: 'Use relative units (%, vw, max-width) instead of fixed pixel widths.',
        impact: 15, passed: false
      });
    }

    const mediaQueries = mobile.mediaQueries || [];
    if (mediaQueries.length > 0) {
      findings.push({
        id: 'mobile-media-queries', category: 'Mobile', severity: 'passed',
        title: 'CSS media queries detected',
        description: mediaQueries.length + ' media query rule(s) found.',
        recommendation: null,
        impact: 0, passed: true
      });
    } else {
      findings.push({
        id: 'mobile-no-media-queries', category: 'Mobile', severity: 'info',
        title: 'No CSS media queries detected',
        description: 'No responsive media queries were found in inline styles.',
        recommendation: 'Use CSS media queries to adapt layout for different screen sizes.',
        impact: 0, passed: false
      });
    }

    return { score: Math.max(0, score), findings };
  },

  auditContent(data) {
    let score = 100;
    const findings = [];
    const d = data || {};
    const content = d.content || {};

    const wordCount = content.wordCount || 0;
    if (wordCount < 100) {
      score -= 15;
      findings.push({
        id: 'content-low-word-count', category: 'Content', severity: 'warning',
        title: 'Low word count detected',
        description: 'Approximately ' + wordCount + ' words found on the page.',
        recommendation: 'Add more substantive content to provide value to users and search engines.',
        impact: 15, passed: false
      });
    } else {
      findings.push({
        id: 'content-word-count-ok', category: 'Content', severity: 'passed',
        title: 'Adequate word count',
        description: 'Approximately ' + wordCount + ' words found.',
        recommendation: null,
        impact: 0, passed: true
      });
    }

    if (content.hasVisibleH1) {
      findings.push({
        id: 'content-h1-present', category: 'Content', severity: 'passed',
        title: 'Visible page heading detected',
        description: 'H1: "' + (content.h1Text || '') + '"',
        recommendation: null,
        impact: 0, passed: true
      });
    } else {
      score -= 20;
      findings.push({
        id: 'content-h1-missing', category: 'Content', severity: 'critical',
        title: 'No visible page heading',
        description: 'No H1 heading was detected on this page.',
        recommendation: 'Add a clear H1 heading that describes the page topic.',
        impact: 20, passed: false
      });
    }

    if (content.loremIpsumDetected) {
      score -= 15;
      findings.push({
        id: 'content-lorem-ipsum', category: 'Content', severity: 'warning',
        title: 'Placeholder text detected',
        description: 'Lorem ipsum or similar placeholder text was found on the page.',
        recommendation: 'Replace all placeholder text with real, relevant content before publishing.',
        impact: 15, passed: false
      });
    }

    if (content.placeholderDetected) {
      score -= 15;
      findings.push({
        id: 'content-placeholder', category: 'Content', severity: 'warning',
        title: 'Generic placeholder text detected',
        description: 'Text such as "Your text here" or "Coming soon" was detected.',
        recommendation: 'Replace placeholder text with actual content.',
        impact: 15, passed: false
      });
    }

    const paraCount = content.paragraphCount || 0;
    if (paraCount > 0) {
      findings.push({
        id: 'content-paragraphs', category: 'Content', severity: 'passed',
        title: 'Paragraphs detected',
        description: paraCount + ' paragraph element(s) found.',
        recommendation: null,
        impact: 0, passed: true
      });
    }

    const emptySections = content.emptySections || 0;
    if (emptySections > 5) {
      score -= 10;
      findings.push({
        id: 'content-empty-sections', category: 'Content', severity: 'warning',
        title: 'Many empty sections detected',
        description: emptySections + ' section-like elements appear empty.',
        recommendation: 'Remove or populate empty container elements.',
        impact: 10, passed: false
      });
    }

    const repeated = content.repeatedHeadings || [];
    if (repeated.length > 0) {
      findings.push({
        id: 'content-repeated-headings', category: 'Content', severity: 'info',
        title: 'Repeated headings detected',
        description: repeated.length + ' heading(s) appear multiple times: ' + repeated.slice(0, 3).map(r => '"' + r.text + '"').join(', '),
        recommendation: 'Use unique headings for each section to improve structure and SEO.',
        impact: 0, passed: false
      });
    }

    const ratio = content.textToLinkRatio || 0;
    findings.push({
      id: 'content-text-link-ratio', category: 'Content', severity: 'info',
      title: 'Text-to-link ratio',
      description: 'Approximately ' + ratio + ' words per link.',
      recommendation: ratio < 10 ? 'Consider reducing excessive linking.' : null,
      impact: 0, passed: true
    });

    return { score: Math.max(0, score), findings };
  },

  auditUX(data) {
    let score = 100;
    const findings = [];
    const d = data || {};
    const ux = d.ux || {};
    const forms = d.forms || [];

    const ctaCount = ux.ctaCount || 0;
    if (ctaCount > 0) {
      findings.push({
        id: 'ux-cta-detected', category: 'UX', severity: 'passed',
        title: 'Call-to-action elements detected',
        description: ctaCount + ' CTA element(s) found: ' + ux.ctaElements.slice(0, 3).map(c => '"' + c.text + '"').join(', ') + (ctaCount > 3 ? '...' : ''),
        recommendation: null,
        impact: 0, passed: true
      });
    } else {
      findings.push({
        id: 'ux-cta-missing', category: 'UX', severity: 'info',
        title: 'No obvious CTA detected',
        description: 'No clear call-to-action buttons or links were found.',
        recommendation: 'Add prominent CTAs like "Get Started", "Contact Us", or "Learn More".',
        impact: 0, passed: false
      });
    }

    const hasContact = (ux.emailsDetected || 0) > 0 || (ux.phoneLinks || 0) > 0 || (ux.emailLinks || 0) > 0 || (ux.contactPageLinks || 0) > 0;
    if (hasContact) {
      findings.push({
        id: 'ux-contact-detected', category: 'UX', severity: 'passed',
        title: 'Contact information detected',
        description: [
          ux.emailsDetected > 0 ? ux.emailsDetected + ' email(s)' : null,
          ux.phoneLinks > 0 ? ux.phoneLinks + ' phone link(s)' : null,
          ux.contactPageLinks > 0 ? ux.contactPageLinks + ' contact page link(s)' : null
        ].filter(Boolean).join(', ') || 'Contact information found.',
        recommendation: null,
        impact: 0, passed: true
      });
    } else {
      findings.push({
        id: 'ux-contact-missing', category: 'UX', severity: 'info',
        title: 'No contact information detected',
        description: 'No email addresses, phone links, or contact page links were found.',
        recommendation: 'Make contact information easy to find for potential customers.',
        impact: 0, passed: false
      });
    }

    if (ux.navigationExists) {
      findings.push({
        id: 'ux-navigation-present', category: 'UX', severity: 'passed',
        title: 'Navigation detected',
        description: ux.navigationLinkCount + ' navigation link(s) found.',
        recommendation: null,
        impact: 0, passed: true
      });
    } else {
      findings.push({
        id: 'ux-navigation-missing', category: 'UX', severity: 'info',
        title: 'No navigation element detected',
        description: 'No <nav> element or navigation role was found.',
        recommendation: 'Use semantic <nav> elements or role="navigation" for site navigation.',
        impact: 0, passed: false
      });
    }

    const trustCount = ux.trustSignalCount || 0;
    if (trustCount > 0) {
      findings.push({
        id: 'ux-trust-detected', category: 'UX', severity: 'passed',
        title: 'Trust signals detected',
        description: trustCount + ' potential trust signal(s) found.',
        recommendation: null,
        impact: 0, passed: true
      });
    } else {
      findings.push({
        id: 'ux-trust-missing', category: 'UX', severity: 'info',
        title: 'No trust signals detected',
        description: 'No testimonials, reviews, certifications, or client logos were detected.',
        recommendation: 'Add testimonials, client logos, or certifications to build trust.',
        impact: 0, passed: false
      });
    }

    if (ux.socialLinks > 0) {
      findings.push({
        id: 'ux-social-detected', category: 'UX', severity: 'passed',
        title: 'Social media links detected',
        description: ux.socialLinks + ' social media link(s) found.',
        recommendation: null,
        impact: 0, passed: true
      });
    } else {
      findings.push({
        id: 'ux-social-missing', category: 'UX', severity: 'info',
        title: 'No social media links detected',
        description: 'No links to social media profiles were found.',
        recommendation: 'Add social media links to increase engagement and credibility.',
        impact: 0, passed: false
      });
    }

    if (forms.length > 0) {
      findings.push({
        id: 'ux-forms-present', category: 'UX', severity: 'passed',
        title: 'Forms detected',
        description: forms.length + ' form(s) with ' + (ux.totalFormFields || 0) + ' total field(s).',
        recommendation: null,
        impact: 0, passed: true
      });

      const formsWithoutSubmit = forms.filter(f => !f.hasSubmit).length;
      if (formsWithoutSubmit > 0) {
        score -= 10;
        findings.push({
          id: 'ux-form-no-submit', category: 'UX', severity: 'warning',
          title: 'Forms without submit buttons',
          description: formsWithoutSubmit + ' form(s) lack a submit button.',
          recommendation: 'Ensure every form has a clear submit button.',
          impact: 10, passed: false
        });
      }
    }

    return { score: Math.max(0, score), findings };
  },

  auditTechnical(data) {
    let score = 100;
    const findings = [];
    const d = data || {};
    const tech = d.technical || {};

    if (tech.https) {
      findings.push({
        id: 'tech-https', category: 'Technical', severity: 'passed',
        title: 'HTTPS enabled',
        description: 'The page is served over a secure HTTPS connection.',
        recommendation: null,
        impact: 0, passed: true
      });
    } else {
      score -= 30;
      findings.push({
        id: 'tech-no-https', category: 'Technical', severity: 'critical',
        title: 'HTTPS not enabled',
        description: 'The page is served over an insecure HTTP connection.',
        recommendation: 'Enable HTTPS with an SSL certificate for all pages.',
        impact: 30, passed: false
      });
    }

    if (tech.mixedContent > 0) {
      score -= 25;
      findings.push({
        id: 'tech-mixed-content', category: 'Technical', severity: 'critical',
        title: 'Mixed content detected',
        description: tech.mixedContent + ' insecure resource(s) loaded on an HTTPS page.',
        recommendation: 'Update all resource URLs to use HTTPS.',
        impact: 25, passed: false
      });
    } else if (tech.https) {
      findings.push({
        id: 'tech-no-mixed-content', category: 'Technical', severity: 'passed',
        title: 'No mixed content detected',
        description: 'All resources appear to be loaded securely.',
        recommendation: null,
        impact: 0, passed: true
      });
    }

    if (tech.doctype === 'html') {
      findings.push({
        id: 'tech-doctype', category: 'Technical', severity: 'passed',
        title: 'Valid HTML5 DOCTYPE',
        description: 'The page uses the HTML5 DOCTYPE.',
        recommendation: null,
        impact: 0, passed: true
      });
    } else {
      findings.push({
        id: 'tech-doctype-missing', category: 'Technical', severity: 'info',
        title: 'DOCTYPE check',
        description: tech.doctype ? 'DOCTYPE: ' + tech.doctype : 'No DOCTYPE detected.',
        recommendation: 'Use <!DOCTYPE html> for standards-mode rendering.',
        impact: 0, passed: false
      });
    }

    if (tech.charset) {
      findings.push({
        id: 'tech-charset', category: 'Technical', severity: 'passed',
        title: 'Character encoding declared',
        description: 'Charset: ' + tech.charset,
        recommendation: null,
        impact: 0, passed: true
      });
    } else {
      findings.push({
        id: 'tech-charset-missing', category: 'Technical', severity: 'info',
        title: 'Character encoding not declared',
        description: 'No charset was detected.',
        recommendation: 'Add <meta charset="UTF-8"> as the first element in <head>.',
        impact: 0, passed: false
      });
    }

    if (tech.structuredDataCount > 0) {
      findings.push({
        id: 'tech-structured-data', category: 'Technical', severity: 'passed',
        title: 'Structured data present',
        description: tech.structuredDataCount + ' JSON-LD block(s). Types: ' + (tech.structuredDataTypes || []).slice(0, 5).join(', '),
        recommendation: null,
        impact: 0, passed: true
      });
    }

    findings.push({
      id: 'tech-scripts-summary', category: 'Technical', severity: 'info',
      title: 'Script summary',
      description: (tech.inlineScripts || 0) + ' inline, ' + (tech.externalScripts || 0) + ' external script(s).',
      recommendation: null,
      impact: 0, passed: true
    });

    const iframeCount = tech.iframeCount || 0;
    if (iframeCount > 5) {
      score -= 10;
      findings.push({
        id: 'tech-many-iframes', category: 'Technical', severity: 'warning',
        title: 'Excessive iframe usage',
        description: iframeCount + ' iframe(s) detected.',
        recommendation: 'Reduce iframe usage where possible for better performance and security.',
        impact: 10, passed: false
      });
    } else if (iframeCount > 0) {
      findings.push({
        id: 'tech-iframes', category: 'Technical', severity: 'info',
        title: 'Iframes detected',
        description: iframeCount + ' iframe(s) found.',
        recommendation: null,
        impact: 0, passed: true
      });
    }

    return { score: Math.max(0, score), findings };
  },

  generateRecommendations(findings) {
    const recs = [];
    const seen = new Set();

    for (const finding of findings) {
      if (finding.passed || finding.severity === 'info') continue;
      if (!finding.recommendation) continue;

      const key = finding.id;
      if (seen.has(key)) continue;
      seen.add(key);

      recs.push({
        id: finding.id,
        category: finding.category,
        severity: finding.severity,
        title: finding.title,
        recommendation: finding.recommendation,
        impact: finding.impact
      });
    }

    const severityOrder = { critical: 0, warning: 1, info: 2 };
    recs.sort((a, b) => {
      if (severityOrder[a.severity] !== severityOrder[b.severity]) {
        return severityOrder[a.severity] - severityOrder[b.severity];
      }
      return b.impact - a.impact;
    });

    return recs;
  }
};

if (typeof module !== 'undefined' && module.exports) {
  module.exports = AuditEngine;
}
