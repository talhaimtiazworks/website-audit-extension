/**
 * Website Audit Extension - Content Script
 * Collects raw DOM data from the active webpage
 * TalhaImtiazWorks
 */

(function() {
  'use strict';

  // Prevent double-injection
  if (window.__websiteAuditInjected) return;
  window.__websiteAuditInjected = true;

  /**
   * Safe wrapper for any DOM operation
   */
  function safe(fn, fallback = null) {
    try {
      const result = fn();
      return result === undefined ? fallback : result;
    } catch (e) {
      return fallback;
    }
  }

  /**
   * Collect all page data
   */
  function collectPageData() {
    const data = {
      url: '',
      title: '',
      domain: '',
      protocol: '',
      language: null,
      meta: {},
      og: {},
      headings: {},
      images: [],
      links: [],
      forms: [],
      buttons: [],
      scripts: [],
      stylesheets: [],
      domStats: {},
      accessibility: {},
      performance: {},
      mobile: {},
      content: {},
      ux: {},
      technical: {}
    };

    // Basic page info
    data.url = safe(() => location.href, '');
    data.title = safe(() => document.title, '');
    data.domain = safe(() => location.hostname.replace(/^www\./, ''), '');
    data.protocol = safe(() => location.protocol, '');
    data.language = safe(() => document.documentElement.lang || document.documentElement.getAttribute('xml:lang') || null, null);

    // Meta tags
    safe(() => {
      const getMeta = (name) => {
        const el = document.querySelector(`meta[name="${CSS.escape(name)}"]`);
        return el ? el.content : null;
      };
      const getMetaProp = (prop) => {
        const el = document.querySelector(`meta[property="${CSS.escape(prop)}"]`);
        return el ? el.content : null;
      };

      data.meta.description = getMeta('description');
      data.meta.viewport = getMeta('viewport');
      data.meta.robots = getMeta('robots');
      data.meta.canonical = document.querySelector('link[rel="canonical"]')?.href || null;
      data.meta.themeColor = getMeta('theme-color');
      data.meta.author = getMeta('author');

      data.og.title = getMetaProp('og:title');
      data.og.description = getMetaProp('og:description');
      data.og.image = getMetaProp('og:image');
      data.og.url = getMetaProp('og:url');
      data.og.type = getMetaProp('og:type');
      data.og.siteName = getMetaProp('og:site_name');
    });

    // Headings
    safe(() => {
      for (let i = 1; i <= 6; i++) {
        const elements = Array.from(document.querySelectorAll(`h${i}`));
        data.headings[`h${i}`] = {
          count: elements.length,
          texts: elements.map(el => el.textContent.trim()).filter(t => t.length > 0)
        };
      }
    });

    // Images
    safe(() => {
      const imgs = Array.from(document.querySelectorAll('img'));
      data.images = imgs.map(img => ({
        src: img.currentSrc || img.src || '',
        alt: img.getAttribute('alt'),
        width: img.width,
        height: img.height,
        naturalWidth: img.naturalWidth || 0,
        naturalHeight: img.naturalHeight || 0,
        hasWidthHeight: img.hasAttribute('width') && img.hasAttribute('height'),
        isLazy: img.loading === 'lazy',
        isInViewport: isInViewport(img)
      }));
    });

    // Links
    safe(() => {
      const links = Array.from(document.querySelectorAll('a'));
      const currentHost = location.hostname;
      data.links = links.map(a => {
        const href = a.getAttribute('href');
        const text = a.textContent.trim();
        const hasIcon = a.querySelector('svg, i, [class*="icon"], [class*="fa-"]') !== null;
        return {
          href: a.href || '',
          rawHref: href,
          text: text,
          isExternal: safe(() => a.hostname !== currentHost && a.hostname !== '', false),
          hasHref: a.hasAttribute('href'),
          isEmpty: !href || href === '#' || href === 'javascript:void(0)' || href === 'javascript:;',
          hasAccessibleName: !!(text || a.getAttribute('aria-label') || a.getAttribute('aria-labelledby') || a.getAttribute('title')),
          hasIconOnly: hasIcon && !text && !a.getAttribute('aria-label') && !a.getAttribute('title'),
          isInViewport: isInViewport(a)
        };
      });
    });

    // Forms
    safe(() => {
      const forms = Array.from(document.querySelectorAll('form'));
      data.forms = forms.map(form => {
        const inputs = Array.from(form.querySelectorAll('input, select, textarea'));
        const buttons = Array.from(form.querySelectorAll('button, input[type="submit"], input[type="button"]'));
        return {
          action: form.action || '',
          method: (form.method || 'get').toLowerCase(),
          inputCount: inputs.length,
          buttonCount: buttons.length,
          hasSubmit: buttons.some(b =>
            b.type === 'submit' ||
            b.getAttribute('type') === 'submit' ||
            b.tagName.toLowerCase() === 'input' && (b.type === 'submit' || b.type === 'button')
          ),
          inputsWithoutLabels: inputs.filter(inp => {
            const id = inp.id;
            const ariaLabel = inp.getAttribute('aria-label');
            const ariaLabelledBy = inp.getAttribute('aria-labelledby');
            const placeholder = inp.placeholder;
            const hasLabel = id && !!form.querySelector(`label[for="${CSS.escape(id)}"]`);
            const ariaHidden = inp.getAttribute('aria-hidden') === 'true';
            const type = (inp.type || inp.getAttribute('type') || 'text').toLowerCase();
            // Hidden inputs and submit buttons don't need labels
            if (type === 'hidden' || type === 'submit' || type === 'button' || type === 'image' || ariaHidden) return false;
            return !hasLabel && !ariaLabel && !ariaLabelledBy && !placeholder;
          }).length
        };
      });
    });

    // Buttons
    safe(() => {
      const btns = Array.from(document.querySelectorAll('button, [role="button"], input[type="submit"], input[type="button"]'));
      data.buttons = btns.map(btn => {
        const text = btn.textContent?.trim() || btn.value || '';
        return {
          text: text,
          hasText: text.length > 0,
          isVisible: isInViewport(btn),
          isCTA: isCTAText(text)
        };
      });
    });

    // Scripts
    safe(() => {
      const scripts = Array.from(document.querySelectorAll('script'));
      data.scripts = scripts.map(s => ({
        src: s.src || null,
        isInline: !s.src,
        isAsync: s.async,
        isDefer: s.defer,
        isInHead: s.parentElement?.tagName?.toLowerCase() === 'head'
      }));
    });

    // Stylesheets
    safe(() => {
      const links = Array.from(document.querySelectorAll('link[rel="stylesheet"]'));
      data.stylesheets = links.map(s => ({
        href: s.href || '',
        isInHead: s.parentElement?.tagName?.toLowerCase() === 'head',
        isExternal: s.href && !s.href.startsWith(location.origin)
      }));
    });

    // DOM Stats
    safe(() => {
      const allElements = document.querySelectorAll('*');
      const bodyText = document.body ? document.body.innerText || '' : '';
      data.domStats = {
        elementCount: allElements.length,
        bodyTextLength: bodyText.length,
        wordCount: bodyText.trim().split(/\s+/).filter(w => w.length > 0).length,
        paragraphCount: document.querySelectorAll('p').length,
        divCount: document.querySelectorAll('div').length,
        spanCount: document.querySelectorAll('span').length,
        listCount: document.querySelectorAll('ul, ol').length,
        tableCount: document.querySelectorAll('table').length,
        documentSize: document.documentElement.outerHTML.length
      };
    });

    // Accessibility
    safe(() => {
      const allImages = Array.from(document.querySelectorAll('img'));
      const allLinks = Array.from(document.querySelectorAll('a'));
      const allInputs = Array.from(document.querySelectorAll('input, select, textarea'));
      const allButtons = Array.from(document.querySelectorAll('button'));

      data.accessibility = {
        htmlLang: data.language,
        imagesWithoutAlt: allImages.filter(img => !img.hasAttribute('alt')).length,
        imagesWithEmptyAlt: allImages.filter(img => img.hasAttribute('alt') && img.getAttribute('alt') === '').length,
        imagesWithAlt: allImages.filter(img => img.hasAttribute('alt') && img.getAttribute('alt') !== '').length,
        totalImages: allImages.length,
        emptyLinks: allLinks.filter(a => {
          const href = a.getAttribute('href');
          return !href || href === '#' || href === '';
        }).length,
        linksWithOnlyIcons: allLinks.filter(a => {
          const text = a.textContent.trim();
          const hasIcon = a.querySelector('svg, i, [class*="icon"], [class*="fa-"], img') !== null;
          return hasIcon && !text && !a.getAttribute('aria-label') && !a.getAttribute('title');
        }).length,
        formInputsWithoutLabels: allInputs.filter(inp => {
          const id = inp.id;
          const type = (inp.type || 'text').toLowerCase();
          if (type === 'hidden' || type === 'submit' || type === 'button' || type === 'image') return false;
          const hasLabel = id && !!document.querySelector(`label[for="${CSS.escape(id)}"]`);
          const ariaLabel = inp.getAttribute('aria-label');
          const ariaLabelledBy = inp.getAttribute('aria-labelledby');
          const placeholder = inp.placeholder;
          return !hasLabel && !ariaLabel && !ariaLabelledBy && !placeholder;
        }).length,
        buttonsWithoutText: allButtons.filter(btn => {
          const text = btn.textContent.trim();
          const ariaLabel = btn.getAttribute('aria-label');
          return !text && !ariaLabel && !btn.querySelector('img[alt]');
        }).length,
        ariaLandmarks: Array.from(new Set(
          Array.from(document.querySelectorAll('[role]')).map(el => el.getAttribute('role'))
        )),
        skipLinkExists: !!document.querySelector('a[href^="#"]'),
        focusableElements: document.querySelectorAll('a, button, input, select, textarea, [tabindex]:not([tabindex="-1"])').length
      };
    });

    // Performance signals
    safe(() => {
      const perfEntries = performance.getEntriesByType ? performance.getEntriesByType('resource') : [];
      const navEntry = performance.getEntriesByType ? performance.getEntriesByType('navigation')[0] : null;

      data.performance = {
        resourceCount: perfEntries.length,
        documentSize: data.domStats.documentSize,
        domElementCount: data.domStats.elementCount,
        imageCount: data.images.length,
        scriptCount: data.scripts.length,
        stylesheetCount: data.stylesheets.length,
        imagesWithoutDimensions: data.images.filter(img => !img.hasWidthHeight).length,
        largeImages: data.images.filter(img => img.naturalWidth > 2000 || img.naturalHeight > 2000).length,
        renderBlockingScripts: data.scripts.filter(s => s.isInHead && !s.isAsync && !s.isDefer && !s.isInline).length,
        renderBlockingStyles: data.stylesheets.filter(s => s.isInHead).length,
        timing: navEntry ? {
          domContentLoaded: Math.round(navEntry.domContentLoadedEventEnd),
          loadComplete: Math.round(navEntry.loadEventEnd),
          responseEnd: Math.round(navEntry.responseEnd)
        } : null
      };
    });

    // Mobile / Responsive
    safe(() => {
      const viewportMeta = document.querySelector('meta[name="viewport"]');
      const viewportContent = viewportMeta ? viewportMeta.content : null;

      data.mobile = {
        viewportMetaExists: !!viewportMeta,
        viewportContent: viewportContent,
        hasWidthDeviceWidth: viewportContent ? viewportContent.includes('width=device-width') : false,
        hasInitialScale: viewportContent ? viewportContent.includes('initial-scale') : false,
        horizontalOverflow: document.documentElement.scrollWidth > window.innerWidth,
        scrollWidth: document.documentElement.scrollWidth,
        windowWidth: window.innerWidth,
        windowHeight: window.innerHeight,
        devicePixelRatio: window.devicePixelRatio || 1,
        mediaQueries: Array.from(new Set(
          Array.from(document.querySelectorAll('style')).flatMap(style => {
            try {
              const sheet = style.sheet;
              if (!sheet) return [];
              return Array.from(sheet.cssRules || [])
                .filter(r => r.type === CSSRule.MEDIA_RULE)
                .map(r => r.conditionText || r.media.mediaText);
            } catch {
              return [];
            }
          })
        )).slice(0, 20),
        fixedWidthElements: Array.from(document.querySelectorAll('*')).filter(el => {
          const width = window.getComputedStyle(el).width;
          return width.includes('px') && parseInt(width) > window.innerWidth;
        }).length
      };
    });

    // Content quality
    safe(() => {
      const bodyText = document.body ? document.body.innerText || '' : '';
      const visibleText = bodyText.substring(0, 10000);
      const headings = [];
      for (let i = 1; i <= 6; i++) {
        document.querySelectorAll(`h${i}`).forEach(h => headings.push(h.textContent.trim()));
      }

      // Detect repeated headings
      const headingCounts = {};
      headings.forEach(h => {
        const lower = h.toLowerCase();
        headingCounts[lower] = (headingCounts[lower] || 0) + 1;
      });
      const repeatedHeadings = Object.entries(headingCounts)
        .filter(([_, count]) => count > 1)
        .map(([text, count]) => ({ text, count }));

      data.content = {
        wordCount: data.domStats.wordCount,
        paragraphCount: data.domStats.paragraphCount,
        visibleText: visibleText,
        hasVisibleH1: data.headings.h1 && data.headings.h1.count > 0,
        h1Text: data.headings.h1 && data.headings.h1.texts.length > 0 ? data.headings.h1.texts[0] : null,
        loremIpsumDetected: containsLoremIpsum(visibleText),
        placeholderDetected: containsPlaceholder(visibleText),
        repeatedHeadings: repeatedHeadings,
        emptySections: Array.from(document.querySelectorAll('section, div, article')).filter(el => {
          const text = el.textContent.trim();
          return text.length < 10 && el.children.length === 0;
        }).length,
        textToLinkRatio: data.links.length > 0 ? Math.round(data.domStats.wordCount / data.links.length) : data.domStats.wordCount
      };
    });

    // UX / Conversion
    safe(() => {
      const bodyText = document.body ? document.body.innerText || '' : '';
      const allLinks = Array.from(document.querySelectorAll('a'));
      const allButtons = Array.from(document.querySelectorAll('button, [role="button"], .btn, [class*="button"]'));

      // CTA detection
      const ctaPhrases = [
        'get started', 'contact us', 'book now', 'buy now', 'learn more',
        'request a quote', 'sign up', 'start free', 'get a demo', 'subscribe',
        'download', 'free trial', 'join now', 'shop now', 'order now',
        'get in touch', 'call now', 'schedule', 'register', 'apply now'
      ];

      const ctaElements = [];
      allButtons.forEach(btn => {
        const text = btn.textContent.trim().toLowerCase();
        if (ctaPhrases.some(p => text.includes(p))) {
          ctaElements.push({ text: btn.textContent.trim(), tag: btn.tagName.toLowerCase() });
        }
      });
      allLinks.forEach(a => {
        const text = a.textContent.trim().toLowerCase();
        if (ctaPhrases.some(p => text.includes(p))) {
          ctaElements.push({ text: a.textContent.trim(), tag: 'a' });
        }
      });

      // Contact info
      const emailPattern = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g;
      const phonePattern = /(?:tel[=:])?\+?[\d\s\-\(\)]{7,}/g;
      const emails = [...bodyText.matchAll(emailPattern)].map(m => m[0]).slice(0, 10);
      const phoneLinks = allLinks.filter(a => a.href && a.href.startsWith('tel:')).length;
      const emailLinks = allLinks.filter(a => a.href && a.href.startsWith('mailto:')).length;
      const contactPageLinks = allLinks.filter(a => {
        const href = (a.getAttribute('href') || '').toLowerCase();
        const text = a.textContent.trim().toLowerCase();
        return href.includes('contact') || text.includes('contact');
      }).length;

      // Trust signals
      const trustKeywords = ['testimonial', 'review', 'client', 'partner', 'certified', 'award', 'trusted by', 'as seen on'];
      const trustElements = [];
      document.querySelectorAll('*').forEach(el => {
        const text = el.textContent.trim().toLowerCase();
        if (trustKeywords.some(k => text.includes(k)) && text.length < 200) {
          trustElements.push(text.substring(0, 100));
        }
      });

      // Navigation
      const navElements = document.querySelectorAll('nav, [role="navigation"], header nav, .navbar, .navigation');
      const navLinks = Array.from(navElements).flatMap(nav =>
        Array.from(nav.querySelectorAll('a')).map(a => a.textContent.trim()).filter(t => t)
      );

      // Social links
      const socialDomains = ['facebook.com', 'twitter.com', 'x.com', 'instagram.com', 'linkedin.com', 'youtube.com', 'tiktok.com', 'pinterest.com'];
      const socialLinks = allLinks.filter(a => {
        try {
          return socialDomains.some(d => a.hostname.includes(d));
        } catch { return false; }
      }).length;

      data.ux = {
        ctaElements: ctaElements.slice(0, 10),
        ctaCount: ctaElements.length,
        emailsDetected: emails.length,
        phoneLinks: phoneLinks,
        emailLinks: emailLinks,
        contactPageLinks: contactPageLinks,
        trustSignals: [...new Set(trustElements)].slice(0, 10),
        trustSignalCount: [...new Set(trustElements)].length,
        navigationExists: navElements.length > 0,
        navigationLinkCount: navLinks.length,
        socialLinks: socialLinks,
        formCount: data.forms.length,
        totalFormFields: data.forms.reduce((sum, f) => sum + f.inputCount, 0)
      };
    });

    // Technical / Security
    safe(() => {
      const allScripts = Array.from(document.querySelectorAll('script'));
      const allLinks = Array.from(document.querySelectorAll('link, img, script, iframe, audio, video'));
      const currentProtocol = location.protocol;

      // Mixed content detection
      const insecureResources = allLinks.filter(el => {
        const src = el.src || el.href || '';
        return src.startsWith('http:') && currentProtocol === 'https:';
      }).length;

      // Structured data
      const jsonLdScripts = Array.from(document.querySelectorAll('script[type="application/ld+json"]'));
      const structuredData = jsonLdScripts.map(s => {
        try {
          return JSON.parse(s.textContent);
        } catch {
          return null;
        }
      }).filter(Boolean);

      data.technical = {
        https: currentProtocol === 'https:',
        mixedContent: insecureResources,
        inlineScripts: allScripts.filter(s => !s.src).length,
        externalScripts: allScripts.filter(s => !!s.src).length,
        iframeCount: document.querySelectorAll('iframe').length,
        structuredDataCount: structuredData.length,
        structuredDataTypes: structuredData.map(d => d['@type'] || 'Unknown').slice(0, 10),
        hasManifest: !!document.querySelector('link[rel="manifest"]'),
        hasServiceWorker: false, // Cannot reliably detect from DOM
        doctype: document.doctype ? document.doctype.name : null,
        charset: document.characterSet || document.charset || null
      };
    });

    return data;
  }

  // Helper: Check if element is in viewport
  function isInViewport(el) {
    try {
      const rect = el.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 &&
        rect.top >= -100 && rect.top <= (window.innerHeight || document.documentElement.clientHeight) + 100;
    } catch {
      return false;
    }
  }

  // Helper: Check if text is CTA
  function isCTAText(text) {
    if (!text) return false;
    const lower = text.toLowerCase();
    const phrases = [
      'get started', 'contact us', 'book now', 'buy now', 'learn more',
      'request a quote', 'sign up', 'start free', 'get a demo', 'subscribe',
      'download', 'free trial', 'join now', 'shop now', 'order now'
    ];
    return phrases.some(p => lower.includes(p));
  }

  // Helper: Lorem ipsum detection
  function containsLoremIpsum(text) {
    if (!text) return false;
    const lower = text.toLowerCase();
    const patterns = [
      'lorem ipsum', 'dolor sit amet', 'consectetur adipiscing',
      'sed do eiusmod', 'ut labore et dolore', 'magna aliqua'
    ];
    return patterns.some(p => lower.includes(p));
  }

  // Helper: Placeholder detection
  function containsPlaceholder(text) {
    if (!text) return false;
    const lower = text.toLowerCase();
    const patterns = [
      'your text here', 'coming soon', 'placeholder', 'sample text',
      'content here', 'insert text', 'todo', 'fixme', 'under construction'
    ];
    return patterns.some(p => lower.includes(p));
  }

  // Message listener
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request && request.action === 'collectData') {
      // Use setTimeout to not block and handle async properly
      setTimeout(() => {
        try {
          const data = collectPageData();
          sendResponse({ success: true, data: data });
        } catch (err) {
          sendResponse({ success: false, error: err.message });
        }
      }, 0);
      return true; // Keep channel open for async
    }
    return false;
  });

})();
