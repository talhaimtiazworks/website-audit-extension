/**
 * Website Audit Extension - Background Service Worker
 * TalhaImtiazWorks
 */

chrome.runtime.onInstalled.addListener(() => {
  console.log('Website Audit extension installed');
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'ping') {
    sendResponse({ status: 'ok' });
  }
  return false;
});
