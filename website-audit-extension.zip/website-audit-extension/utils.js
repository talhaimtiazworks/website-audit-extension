/**
 * Website Audit Extension - Shared Utilities
 * TalhaImtiazWorks
 */

const Utils = {
  /**
   * Escape HTML to prevent XSS when displaying page-derived content
   */
  escapeHtml(str) {
    if (typeof str !== 'string') return '';
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  },

  /**
   * Truncate string with ellipsis
   */
  truncate(str, maxLen = 120) {
    if (!str || str.length <= maxLen) return str || '';
    return str.substring(0, maxLen).trim() + '…';
  },

  /**
   * Format number with commas
   */
  formatNumber(num) {
    if (num === null || num === undefined) return '—';
    return num.toLocaleString();
  },

  /**
   * Format date nicely
   */
  formatDate(date) {
    const d = new Date(date);
    return d.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  },

  /**
   * Get domain from URL
   */
  getDomain(url) {
    try {
      return new URL(url).hostname.replace(/^www\./, '');
    } catch {
      return url || 'unknown';
    }
  },

  /**
   * Debounce function calls
   */
  debounce(fn, ms) {
    let timer;
    return (...args) => {
      clearTimeout(timer);
      timer = setTimeout(() => fn(...args), ms);
    };
  },

  /**
   * Deep clone simple objects
   */
  clone(obj) {
    return JSON.parse(JSON.stringify(obj));
  },

  /**
   * Calculate percentage safely
   */
  percentage(part, total) {
    if (!total || total === 0) return 0;
    return Math.round((part / total) * 100);
  },

  /**
   * Get severity color class
   */
  severityColor(severity) {
    switch (severity) {
      case 'critical': return '#EF4444';
      case 'warning': return '#F59E0B';
      case 'passed': return '#22C55E';
      case 'info': return '#6B7280';
      default: return '#6B7280';
    }
  },

  /**
   * Get severity icon
   */
  severityIcon(severity) {
    switch (severity) {
      case 'critical': return '●';
      case 'warning': return '●';
      case 'passed': return '✓';
      case 'info': return '○';
      default: return '○';
    }
  },

  /**
   * Safe JSON parse
   */
  safeJsonParse(str, fallback = null) {
    try {
      return JSON.parse(str);
    } catch {
      return fallback;
    }
  },

  /**
   * Word count from text
   */
  countWords(text) {
    if (!text) return 0;
    return text.trim().split(/\s+/).filter(w => w.length > 0).length;
  },

  /**
   * Check if text contains Lorem Ipsum
   */
  containsLoremIpsum(text) {
    if (!text) return false;
    const lower = text.toLowerCase();
    const patterns = [
      'lorem ipsum',
      'dolor sit amet',
      'consectetur adipiscing',
      'sed do eiusmod',
      'ut labore et dolore'
    ];
    return patterns.some(p => lower.includes(p));
  },

  /**
   * Check for placeholder text patterns
   */
  containsPlaceholder(text) {
    if (!text) return false;
    const lower = text.toLowerCase();
    const patterns = [
      'your text here',
      'coming soon',
      'placeholder',
      'sample text',
      'content here',
      'insert text',
      'todo',
      'fixme'
    ];
    return patterns.some(p => lower.includes(p));
  },

  /**
   * Check if element is visible
   */
  isVisible(el) {
    if (!el) return false;
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  },

  /**
   * Create a DOM element with attributes
   */
  createEl(tag, attrs = {}, text = '') {
    const el = document.createElement(tag);
    Object.entries(attrs).forEach(([k, v]) => {
      if (k === 'className') el.className = v;
      else if (k === 'textContent') el.textContent = v;
      else if (k === 'innerHTML') el.innerHTML = v;
      else el.setAttribute(k, v);
    });
    if (text && !attrs.textContent && !attrs.innerHTML) el.textContent = text;
    return el;
  }
};

// Export for module usage if available
if (typeof module !== 'undefined' && module.exports) {
  module.exports = Utils;
}
