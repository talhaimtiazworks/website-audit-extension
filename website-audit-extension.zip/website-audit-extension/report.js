/**
 * Website Audit Extension - Report Page Logic
 * TalhaImtiazWorks
 */

(function() {
  'use strict';

  let currentAudit = null;

  function init() {
    loadAudit();
    setupEventListeners();
  }

  function setupEventListeners() {
    document.getElementById('btn-print').addEventListener('click', () => {
      window.print();
    });
    document.getElementById('btn-copy-summary').addEventListener('click', copySummary);
  }

  async function loadAudit() {
    try {
      const result = await chrome.storage.local.get('currentAudit');
      const audit = result.currentAudit;

      if (!audit) {
        showError();
        return;
      }

      currentAudit = audit;
      renderReport(audit);
    } catch (e) {
      console.error('Load audit error:', e);
      showError();
    }
  }

  function showError() {
    document.getElementById('report-loading').classList.add('hidden');
    document.getElementById('report-error').classList.remove('hidden');
  }

  function renderReport(audit) {
    document.getElementById('report-loading').classList.add('hidden');
    document.getElementById('report-body').classList.remove('hidden');

    // Hero
    document.getElementById('report-title').textContent = 'Website Audit Report';
    document.getElementById('report-domain').textContent = audit.website.domain || '—';
    document.getElementById('report-url').textContent = Utils.truncate(audit.website.url, 80) || '—';
    document.getElementById('report-date').textContent = Utils.formatDate(audit.website.auditedAt);

    // Score
    const score = audit.overallScore;
    document.getElementById('report-score-number').textContent = score;
    document.getElementById('report-score-label').textContent = getScoreLabel(score);

    const circumference = 2 * Math.PI * 44;
    const offset = circumference - (score / 100) * circumference;
    setTimeout(() => {
      document.getElementById('report-score-ring').style.strokeDashoffset = offset;
    }, 100);

    // Categories
    renderCategories(audit.categories);

    // Findings by severity
    renderFindingsBySeverity(audit.findings);

    // Recommendations
    renderRecommendations(audit.recommendations);

    // Summary
    renderSummary(audit);
  }

  function getScoreLabel(score) {
    if (score >= 90) return 'Excellent';
    if (score >= 80) return 'Good';
    if (score >= 70) return 'Fair';
    if (score >= 50) return 'Needs Work';
    return 'Poor';
  }

  function getScoreColor(score) {
    if (score >= 80) return '#22C55E';
    if (score >= 60) return '#84CC16';
    if (score >= 50) return '#F59E0B';
    if (score >= 30) return '#F97316';
    return '#EF4444';
  }

  function renderCategories(categories) {
    const container = document.getElementById('report-categories');
    container.innerHTML = '';

    const catMap = {
      SEO: 'SEO',
      Accessibility: 'Accessibility',
      Performance: 'Performance',
      Mobile: 'Mobile',
      Content: 'Content',
      UX: 'UX / Conversion',
      Technical: 'Technical'
    };

    for (const [key, name] of Object.entries(catMap)) {
      const score = categories[key] || 0;
      const card = document.createElement('div');
      card.className = 'report-cat-card';
      card.innerHTML = `
        <div class="report-cat-header">
          <span class="report-cat-name">${name}</span>
          <span class="report-cat-score" style="color: ${getScoreColor(score)};">${score}</span>
        </div>
        <div class="report-cat-bar">
          <div class="report-cat-bar-fill" style="width: 0%; background: ${getScoreColor(score)};"></div>
        </div>
      `;
      container.appendChild(card);
      setTimeout(() => {
        const fill = card.querySelector('.report-cat-bar-fill');
        if (fill) fill.style.width = score + '%';
      }, 150);
    }
  }

  function renderFindingsBySeverity(findings) {
    const critical = findings.filter(f => f.severity === 'critical');
    const warnings = findings.filter(f => f.severity === 'warning');
    const passed = findings.filter(f => f.severity === 'passed');

    renderFindingList('report-critical', critical);
    renderFindingList('report-warnings', warnings);
    renderFindingList('report-passed', passed);

    // Hide empty sections
    toggleSection('section-critical', critical.length > 0);
    toggleSection('section-warnings', warnings.length > 0);
    toggleSection('section-passed', passed.length > 0);
  }

  function renderFindingList(containerId, items) {
    const container = document.getElementById(containerId);
    container.innerHTML = '';

    if (items.length === 0) {
      container.innerHTML = '<div class="report-empty">None found.</div>';
      return;
    }

    for (const item of items) {
      const div = document.createElement('div');
      div.className = 'report-finding';

      const iconText = item.severity === 'passed' ? '✓' : item.severity === 'critical' ? '!' : '!';
      const recHtml = item.recommendation ? `
        <div class="report-finding-rec">
          <span class="report-finding-rec-label">Recommendation</span>
          ${Utils.escapeHtml(item.recommendation)}
        </div>
      ` : '';

      div.innerHTML = `
        <div class="report-finding-header">
          <div class="report-finding-icon ${item.severity}">${iconText}</div>
          <div class="report-finding-title">${Utils.escapeHtml(item.title)}</div>
        </div>
        <div class="report-finding-desc">${Utils.escapeHtml(item.description)}</div>
        ${recHtml}
      `;
      container.appendChild(div);
    }
  }

  function toggleSection(sectionId, show) {
    const section = document.getElementById(sectionId);
    if (section) {
      section.style.display = show ? 'block' : 'none';
    }
  }

  function renderRecommendations(recommendations) {
    const container = document.getElementById('report-recommendations');
    container.innerHTML = '';

    if (recommendations.length === 0) {
      container.innerHTML = '<div class="report-empty">No recommendations generated.</div>';
      toggleSection('section-recommendations', false);
      return;
    }

    toggleSection('section-recommendations', true);

    for (const rec of recommendations) {
      const div = document.createElement('div');
      div.className = 'report-rec';
      div.innerHTML = `
        <div class="report-rec-header">
          <span class="report-rec-category">${rec.category}</span>
          <span class="report-rec-severity ${rec.severity}">${rec.severity}</span>
        </div>
        <div class="report-rec-title">${Utils.escapeHtml(rec.title)}</div>
        <div class="report-rec-text">${Utils.escapeHtml(rec.recommendation)}</div>
      `;
      container.appendChild(div);
    }
  }

  function renderSummary(audit) {
    const container = document.getElementById('report-summary');
    container.innerHTML = '';

    const d = audit.rawData || {};
    const items = [
      { label: 'Page Title', value: Utils.truncate(audit.website.title, 80) || '—' },
      { label: 'URL', value: Utils.truncate(audit.website.url, 80) || '—' },
      { label: 'Domain', value: audit.website.domain || '—' },
      { label: 'Protocol', value: audit.website.protocol || '—' },
      { label: 'Language', value: audit.website.language || 'Not declared' },
      { label: 'Overall Score', value: audit.overallScore + '/100' },
      { label: 'DOM Elements', value: Utils.formatNumber((d.domStats || {}).elementCount) },
      { label: 'Word Count', value: Utils.formatNumber((d.content || {}).wordCount) },
      { label: 'Images', value: Utils.formatNumber((d.images || []).length) },
      { label: 'Links', value: Utils.formatNumber((d.links || []).length) },
      { label: 'Forms', value: Utils.formatNumber((d.forms || []).length) },
      { label: 'Buttons', value: Utils.formatNumber((d.buttons || []).length) },
      { label: 'Scripts', value: Utils.formatNumber((d.scripts || []).length) },
      { label: 'Stylesheets', value: Utils.formatNumber((d.stylesheets || []).length) },
      { label: 'Document Size', value: ((d.performance || {}).documentSize ? Math.round(d.performance.documentSize / 1024) + ' KB' : '—') },
      { label: 'Critical Issues', value: (audit.criticalIssues || []).length },
      { label: 'Warnings', value: (audit.warnings || []).length },
      { label: 'Passed Checks', value: (audit.passedChecks || []).length }
    ];

    for (const item of items) {
      const div = document.createElement('div');
      div.className = 'report-summary-item';
      div.innerHTML = `
        <span class="report-summary-label">${Utils.escapeHtml(item.label)}</span>
        <span class="report-summary-value">${Utils.escapeHtml(String(item.value))}</span>
      `;
      container.appendChild(div);
    }
  }

  async function copySummary() {
    if (!currentAudit) return;
    try {
      const audit = currentAudit;
      const summary = [
        'Website Audit Report',
        '====================',
        `Domain: ${audit.website.domain || '—'}`,
        `URL: ${audit.website.url || '—'}`,
        `Date: ${Utils.formatDate(audit.website.auditedAt)}`,
        '',
        `Overall Score: ${audit.overallScore}/100`,
        '',
        'Category Scores:',
        `  SEO: ${audit.categories.SEO || 0}`,
        `  Accessibility: ${audit.categories.Accessibility || 0}`,
        `  Performance: ${audit.categories.Performance || 0}`,
        `  Mobile: ${audit.categories.Mobile || 0}`,
        `  Content: ${audit.categories.Content || 0}`,
        `  UX: ${audit.categories.UX || 0}`,
        `  Technical: ${audit.categories.Technical || 0}`,
        '',
        `Critical Issues: ${(audit.criticalIssues || []).length}`,
        `Warnings: ${(audit.warnings || []).length}`,
        `Passed Checks: ${(audit.passedChecks || []).length}`,
        '',
        'Powered by TalhaImtiazWorks'
      ].join('\n');

      await navigator.clipboard.writeText(summary);
      const btn = document.getElementById('btn-copy-summary');
      const originalText = btn.innerHTML;
      btn.innerHTML = '<span>Copied!</span>';
      setTimeout(() => {
        btn.innerHTML = originalText;
      }, 2000);
    } catch (e) {
      console.error('Copy summary error:', e);
      alert('Could not copy summary to clipboard.');
    }
  }

  init();
})();
