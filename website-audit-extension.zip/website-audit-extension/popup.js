/**
 * Website Audit Extension - Popup Logic
 * TalhaImtiazWorks
 */

(function() {
  'use strict';

  // State
  let currentAudit = null;
  let currentTab = null;
  let isAnalyzing = false;

  // DOM refs
  const els = {
    states: {
      initial: document.getElementById('state-initial'),
      loading: document.getElementById('state-loading'),
      restricted: document.getElementById('state-restricted'),
      error: document.getElementById('state-error'),
      results: document.getElementById('state-results'),
      history: document.getElementById('state-history')
    },
    currentDomain: document.getElementById('current-domain'),
    scoreNumber: document.getElementById('score-number'),
    scoreLabel: document.getElementById('score-label'),
    scoreDomain: document.getElementById('score-domain'),
    scoreDate: document.getElementById('score-date'),
    scoreRing: document.getElementById('score-ring-progress'),
    categoryScores: document.getElementById('category-scores'),
    findingsList: document.getElementById('findings-list'),
    recommendationsList: document.getElementById('recommendations-list'),
    overviewGrid: document.getElementById('overview-grid'),
    historyList: document.getElementById('history-list'),
    historyEmpty: document.getElementById('history-empty'),
    loadingStages: document.getElementById('loading-stages'),
    errorMessage: document.getElementById('error-message')
  };

  // Initialize
  function init() {
    setupEventListeners();
    getCurrentDomain();
    loadHistoryPreview();
  }

  function setupEventListeners() {
    document.getElementById('btn-analyze').addEventListener('click', runAudit);
    document.getElementById('btn-try-another').addEventListener('click', () => {
      showState('initial');
    });
    document.getElementById('btn-retry').addEventListener('click', runAudit);
    document.getElementById('btn-history').addEventListener('click', showHistory);
    document.getElementById('btn-back-from-history').addEventListener('click', () => {
      if (currentAudit) {
        showState('results');
      } else {
        showState('initial');
      }
    });
    document.getElementById('btn-clear-history').addEventListener('click', clearHistory);
    document.getElementById('btn-report').addEventListener('click', generateReport);
    document.getElementById('btn-export-json').addEventListener('click', exportJSON);

    // Tabs
    document.querySelectorAll('.tab-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const tab = btn.dataset.tab;
        switchTab(tab);
      });
    });

    // Finding filters
    document.querySelectorAll('.filter-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const filter = btn.dataset.filter;
        switchFilter(filter);
      });
    });
  }

  // Show a specific state
  function showState(name) {
    Object.values(els.states).forEach(el => el.classList.add('hidden'));
    if (els.states[name]) {
      els.states[name].classList.remove('hidden');
    }
  }

  // Get current domain
  function getCurrentDomain() {
    chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
      if (!tabs || !tabs[0]) return;
      currentTab = tabs[0];
      const domain = Utils.getDomain(tabs[0].url);
      els.currentDomain.textContent = domain;
    });
  }

  // Run audit
  async function runAudit() {
    if (isAnalyzing) return;
    isAnalyzing = true;

    showState('loading');
    resetStages();

    try {
      const tabs = await queryTabs();
      if (!tabs || !tabs[0]) {
        throw new Error('Could not access current tab');
      }
      currentTab = tabs[0];
      const tabId = tabs[0].id;
      const url = tabs[0].url || '';

      // Check for restricted pages
      if (isRestrictedUrl(url)) {
        showState('restricted');
        isAnalyzing = false;
        return;
      }

      updateStage('connect', 'active');
      await delay(100);

      // Send message to content script
      updateStage('structure', 'active');
      const response = await sendMessage(tabId, { action: 'collectData' }, 15000);

      if (!response) {
        throw new Error('No response from page. The page may be restricted or the content script has not loaded yet.');
      }

      if (!response.success) {
        throw new Error(response.error || 'Failed to collect page data');
      }

      updateStage('structure', 'complete');
      await delay(50);

      updateStage('seo', 'active');
      await delay(50);
      updateStage('seo', 'complete');

      updateStage('accessibility', 'active');
      await delay(50);
      updateStage('accessibility', 'complete');

      updateStage('ux', 'active');
      await delay(50);
      updateStage('ux', 'complete');

      updateStage('score', 'active');
      const result = AuditEngine.run(response.data);
      currentAudit = result;
      updateStage('score', 'complete');

      updateStage('recommend', 'active');
      await delay(50);
      updateStage('recommend', 'complete');

      // Save to history
      await saveToHistory(result);

      // Render
      renderResults(result);
      showState('results');

    } catch (error) {
      console.error('Audit error:', error);
      els.errorMessage.textContent = error.message || 'An unexpected error occurred.';
      showState('error');
    } finally {
      isAnalyzing = false;
    }
  }

  function isRestrictedUrl(url) {
    if (!url) return true;
    const restricted = [
      'chrome://', 'chrome-extension://', 'edge://', 'edge-extension://',
      'about:', 'file://', 'devtools://', 'view-source:', 'javascript:',
      'data:', 'blob:', 'https://chrome.google.com/webstore'
    ];
    return restricted.some(r => url.startsWith(r));
  }

  function queryTabs() {
    return new Promise((resolve) => {
      chrome.tabs.query({ active: true, currentWindow: true }, resolve);
    });
  }

  function sendMessage(tabId, message, timeout) {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        resolve(null);
      }, timeout);

      try {
        chrome.tabs.sendMessage(tabId, message, response => {
          clearTimeout(timer);
          if (chrome.runtime.lastError) {
            resolve(null);
          } else {
            resolve(response);
          }
        });
      } catch (e) {
        clearTimeout(timer);
        resolve(null);
      }
    });
  }

  function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  function resetStages() {
    document.querySelectorAll('.stage').forEach(s => {
      s.classList.remove('active', 'complete');
    });
  }

  function updateStage(name, status) {
    const stage = document.querySelector(`.stage[data-stage="${name}"]`);
    if (!stage) return;
    stage.classList.remove('active', 'complete');
    if (status === 'active') {
      stage.classList.add('active');
    } else if (status === 'complete') {
      stage.classList.add('complete');
    }
  }

  // Render results
  function renderResults(result) {
    if (!result) return;

    // Score circle
    const score = result.overallScore;
    els.scoreNumber.textContent = score;
    els.scoreLabel.textContent = getScoreLabel(score);
    els.scoreDomain.textContent = result.website.domain || '—';
    els.scoreDate.textContent = Utils.formatDate(result.website.auditedAt);

    // Animate ring
    const circumference = 2 * Math.PI * 42; // r=42
    const offset = circumference - (score / 100) * circumference;
    setTimeout(() => {
      els.scoreRing.style.strokeDashoffset = offset;
    }, 100);

    // Category scores
    renderCategoryScores(result.categories);

    // Findings
    renderFindings(result.findings, 'all');

    // Recommendations
    renderRecommendations(result.recommendations);

    // Overview
    renderOverview(result);
  }

  function getScoreLabel(score) {
    if (score >= 90) return 'Excellent';
    if (score >= 80) return 'Good';
    if (score >= 70) return 'Fair';
    if (score >= 50) return 'Needs Work';
    return 'Poor';
  }

  function getScoreColorClass(score) {
    if (score >= 80) return 'score-excellent';
    if (score >= 60) return 'score-good';
    if (score >= 50) return 'score-average';
    if (score >= 30) return 'score-poor';
    return 'score-critical';
  }

  function getBarColor(score) {
    if (score >= 80) return '#22C55E';
    if (score >= 60) return '#84CC16';
    if (score >= 50) return '#F59E0B';
    if (score >= 30) return '#F97316';
    return '#EF4444';
  }

  // Render category scores
  function renderCategoryScores(categories) {
    els.categoryScores.innerHTML = '';
    const catMap = {
      SEO: 'SEO',
      Accessibility: 'Accessibility',
      Performance: 'Performance',
      Mobile: 'Mobile',
      Content: 'Content',
      UX: 'UX',
      Technical: 'Technical'
    };

    for (const [key, name] of Object.entries(catMap)) {
      const score = categories[key] || 0;
      const card = document.createElement('div');
      card.className = 'category-card';
      card.innerHTML = `
        <div class="category-card-header">
          <span class="category-card-name">${name}</span>
          <span class="category-card-score ${getScoreColorClass(score)}">${score}</span>
        </div>
        <div class="category-card-bar">
          <div class="category-card-bar-fill" style="width: 0%; background: ${getBarColor(score)};"></div>
        </div>
      `;
      els.categoryScores.appendChild(card);

      // Animate bar
      setTimeout(() => {
        const fill = card.querySelector('.category-card-bar-fill');
        if (fill) fill.style.width = score + '%';
      }, 150);
    }
  }

  // Render findings
  function renderFindings(findings, filter) {
    els.findingsList.innerHTML = '';

    let filtered = findings;
    if (filter !== 'all') {
      filtered = findings.filter(f => f.severity === filter);
    }

    // Sort: critical, warning, info, passed
    const order = { critical: 0, warning: 1, info: 2, passed: 3 };
    filtered = [...filtered].sort((a, b) => order[a.severity] - order[b.severity]);

    if (filtered.length === 0) {
      els.findingsList.innerHTML = `
        <div class="empty-state">
          <div class="empty-state-title">No ${filter === 'all' ? '' : filter} findings</div>
          <div class="empty-state-desc">${getEmptyStateText(filter)}</div>
        </div>
      `;
      return;
    }

    for (const finding of filtered) {
      const item = document.createElement('div');
      item.className = 'finding-item';

      const iconClass = finding.severity;
      const iconText = finding.severity === 'passed' ? '✓' : finding.severity === 'critical' ? '!' : finding.severity === 'warning' ? '!' : 'i';

      let recHtml = '';
      if (finding.recommendation) {
        recHtml = `
          <div class="finding-rec">
            <span class="finding-rec-label">Recommendation</span>
            ${Utils.escapeHtml(finding.recommendation)}
          </div>
        `;
      }

      item.innerHTML = `
        <div class="finding-header">
          <div class="finding-icon ${iconClass}">${iconText}</div>
          <div class="finding-title">${Utils.escapeHtml(finding.title)}</div>
        </div>
        <div class="finding-desc">${Utils.escapeHtml(finding.description)}</div>
        ${recHtml}
      `;
      els.findingsList.appendChild(item);
    }
  }

  function getEmptyStateText(filter) {
    switch (filter) {
      case 'critical': return 'No critical issues detected. Great job!';
      case 'warning': return 'No warnings detected.';
      case 'passed': return 'No passed checks in this category.';
      default: return 'No findings to display.';
    }
  }

  // Switch filter
  function switchFilter(filter) {
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    document.querySelector(`.filter-btn[data-filter="${filter}"]`).classList.add('active');
    if (currentAudit) {
      renderFindings(currentAudit.findings, filter);
    }
  }

  // Switch tab
  function switchTab(tab) {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelector(`.tab-btn[data-tab="${tab}"]`).classList.add('active');
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    document.getElementById('tab-' + tab).classList.add('active');
  }

  // Render recommendations
  function renderRecommendations(recommendations) {
    els.recommendationsList.innerHTML = '';

    if (recommendations.length === 0) {
      els.recommendationsList.innerHTML = `
        <div class="empty-state">
          <div class="empty-state-title">No recommendations</div>
          <div class="empty-state-desc">No issues requiring recommendations were found.</div>
        </div>
      `;
      return;
    }

    for (const rec of recommendations) {
      const item = document.createElement('div');
      item.className = 'recommendation-item';
      item.innerHTML = `
        <div class="rec-header">
          <span class="rec-category">${rec.category}</span>
          <span class="rec-severity ${rec.severity}">${rec.severity}</span>
        </div>
        <div class="rec-title">${Utils.escapeHtml(rec.title)}</div>
        <div class="rec-text">${Utils.escapeHtml(rec.recommendation)}</div>
      `;
      els.recommendationsList.appendChild(item);
    }
  }

  // Render overview
  function renderOverview(result) {
    els.overviewGrid.innerHTML = '';
    const d = result.rawData || {};
    const items = [
      { label: 'Page Title', value: Utils.truncate(result.website.title, 60) || '—' },
      { label: 'URL', value: Utils.truncate(result.website.url, 60) || '—' },
      { label: 'Domain', value: result.website.domain || '—' },
      { label: 'Protocol', value: result.website.protocol || '—' },
      { label: 'Language', value: result.website.language || 'Not declared' },
      { label: 'DOM Elements', value: Utils.formatNumber((d.domStats || {}).elementCount) },
      { label: 'Word Count', value: Utils.formatNumber((d.content || {}).wordCount) },
      { label: 'Images', value: Utils.formatNumber((d.images || []).length) },
      { label: 'Links', value: Utils.formatNumber((d.links || []).length) },
      { label: 'Forms', value: Utils.formatNumber((d.forms || []).length) },
      { label: 'Buttons', value: Utils.formatNumber((d.buttons || []).length) },
      { label: 'Scripts', value: Utils.formatNumber((d.scripts || []).length) },
      { label: 'Stylesheets', value: Utils.formatNumber((d.stylesheets || []).length) },
      { label: 'Document Size', value: ((d.performance || {}).documentSize ? Math.round(d.performance.documentSize / 1024) + ' KB' : '—') }
    ];

    for (const item of items) {
      const div = document.createElement('div');
      div.className = 'overview-item';
      div.innerHTML = `
        <span class="overview-label">${Utils.escapeHtml(item.label)}</span>
        <span class="overview-value">${Utils.escapeHtml(String(item.value))}</span>
      `;
      els.overviewGrid.appendChild(div);
    }
  }

  // History
  async function showHistory() {
    showState('history');
    await renderHistory();
  }

  async function renderHistory() {
    try {
      const result = await chrome.storage.local.get('auditHistory');
      const history = result.auditHistory || [];

      els.historyList.innerHTML = '';

      if (history.length === 0) {
        els.historyList.classList.add('hidden');
        els.historyEmpty.classList.remove('hidden');
        return;
      }

      els.historyList.classList.remove('hidden');
      els.historyEmpty.classList.add('hidden');

      // Sort by date descending
      const sorted = [...history].sort((a, b) => new Date(b.date) - new Date(a.date));

      for (const entry of sorted) {
        const item = document.createElement('div');
        item.className = 'history-item';
        item.setAttribute('tabindex', '0');
        item.setAttribute('role', 'button');

        const scoreColor = getBarColor(entry.overallScore);

        item.innerHTML = `
          <div class="history-score" style="background: ${scoreColor};">${entry.overallScore}</div>
          <div class="history-info">
            <div class="history-domain">${Utils.escapeHtml(entry.domain)}</div>
            <div class="history-date">${Utils.formatDate(entry.date)}</div>
          </div>
          <button class="history-delete" data-domain="${Utils.escapeHtml(entry.domain)}" data-date="${entry.date}" title="Delete" aria-label="Delete audit for ${Utils.escapeHtml(entry.domain)}">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
            </svg>
          </button>
        `;

        item.addEventListener('click', (e) => {
          if (e.target.closest('.history-delete')) return;
          // For now, just re-run audit on current page. In future could load stored audit.
          showState('initial');
        });

        item.addEventListener('keydown', (e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            showState('initial');
          }
        });

        const delBtn = item.querySelector('.history-delete');
        delBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          deleteHistoryEntry(entry.domain, entry.date);
        });

        els.historyList.appendChild(item);
      }
    } catch (e) {
      console.error('History render error:', e);
      els.historyList.innerHTML = '<div class="empty-state"><div class="empty-state-desc">Could not load history.</div></div>';
      els.historyList.classList.remove('hidden');
      els.historyEmpty.classList.add('hidden');
    }
  }

  async function saveToHistory(result) {
    try {
      const entry = {
        domain: result.website.domain || 'unknown',
        url: result.website.url || '',
        date: result.website.auditedAt,
        overallScore: result.overallScore,
        categories: result.categories
      };

      const stored = await chrome.storage.local.get('auditHistory');
      let history = stored.auditHistory || [];
      history.unshift(entry);
      if (history.length > 50) history = history.slice(0, 50);
      await chrome.storage.local.set({ auditHistory: history });
    } catch (e) {
      console.error('Save history error:', e);
    }
  }

  async function deleteHistoryEntry(domain, date) {
    try {
      const stored = await chrome.storage.local.get('auditHistory');
      let history = stored.auditHistory || [];
      history = history.filter(h => !(h.domain === domain && h.date === date));
      await chrome.storage.local.set({ auditHistory: history });
      renderHistory();
    } catch (e) {
      console.error('Delete history error:', e);
    }
  }

  async function clearHistory() {
    if (!confirm('Clear all audit history? This cannot be undone.')) return;
    try {
      await chrome.storage.local.remove('auditHistory');
      renderHistory();
    } catch (e) {
      console.error('Clear history error:', e);
    }
  }

  async function loadHistoryPreview() {
    // Just pre-load to ensure storage works
    try {
      await chrome.storage.local.get('auditHistory');
    } catch (e) {
      console.error('Storage check error:', e);
    }
  }

  // Generate report
  async function generateReport() {
    if (!currentAudit) return;
    try {
      await chrome.storage.local.set({ currentAudit: currentAudit });
      chrome.tabs.create({ url: chrome.runtime.getURL('report.html') });
    } catch (e) {
      console.error('Generate report error:', e);
      alert('Could not open report. Please try again.');
    }
  }

  // Export JSON
  async function exportJSON() {
    if (!currentAudit) return;
    try {
      const dataStr = JSON.stringify(currentAudit, null, 2);
      const blob = new Blob([dataStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `audit-${currentAudit.website.domain || 'website'}-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error('Export JSON error:', e);
      alert('Could not export JSON. Please try again.');
    }
  }

  // Start
  init();
})();
